const express = require('express');
const hbs = require('hbs');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

// ── DATA FILE (local storage via JSON) ──
const DATA_FILE = path.join(__dirname, 'data', 'tasks.json');

function getTasks() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
  } catch {
    return [];
  }
}

function saveTasks(tasks) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(tasks, null, 2));
}

// ── HBS SETUP ──
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

// Register partials folder (header.hbs, footer.hbs)
hbs.registerPartials(path.join(__dirname, 'views', 'partials'));

// Register Handlebars helpers
hbs.registerHelper('eq', (a, b) => a === b);
hbs.registerHelper('not', (val) => !val);
hbs.registerHelper('formatDate', (dateStr) => {
  const d = new Date(dateStr);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
});
hbs.registerHelper('taskCount', (tasks) => tasks.length);
hbs.registerHelper('doneCount', (tasks) => tasks.filter(t => t.completed).length);
hbs.registerHelper('pendingCount', (tasks) => tasks.filter(t => !t.completed).length);
hbs.registerHelper('priorityLabel', (p) => ({ high: '🔴 High', medium: '🟡 Medium', low: '🟢 Low' }[p] || p));

// ── STATIC FILES ──
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));

// ── ROUTES ──

// GET / — show all tasks (with optional filter)
app.get('/', (req, res) => {
  let tasks = getTasks();
  const filter = req.query.filter || 'all';
  const priority = req.query.priority || '';

  let filtered = tasks;
  if (filter === 'active')    filtered = tasks.filter(t => !t.completed);
  if (filter === 'completed') filtered = tasks.filter(t => t.completed);
  if (priority)               filtered = filtered.filter(t => t.priority === priority);

  res.render('index', {
    tasks: filtered,
    allTasks: tasks,
    filter,
    priority,
    filterAll:       filter === 'all',
    filterActive:    filter === 'active',
    filterCompleted: filter === 'completed',
    priHigh:   priority === 'high',
    priMedium: priority === 'medium',
    priLow:    priority === 'low',
    empty: filtered.length === 0
  });
});

// POST /add — add a new task
app.post('/add', (req, res) => {
  const { title, priority, dueDate } = req.body;
  if (!title || !title.trim()) return res.redirect('/');

  const tasks = getTasks();
  tasks.unshift({
    id: Date.now().toString(),
    title: title.trim(),
    priority: priority || 'medium',
    dueDate: dueDate || null,
    completed: false,
    createdAt: new Date().toISOString()
  });
  saveTasks(tasks);
  res.redirect('/');
});

// POST /toggle/:id — toggle complete/incomplete
app.post('/toggle/:id', (req, res) => {
  const tasks = getTasks();
  const task = tasks.find(t => t.id === req.params.id);
  if (task) task.completed = !task.completed;
  saveTasks(tasks);
  res.redirect('back');
});

// POST /delete/:id — delete a task
app.post('/delete/:id', (req, res) => {
  let tasks = getTasks();
  tasks = tasks.filter(t => t.id !== req.params.id);
  saveTasks(tasks);
  res.redirect('back');
});

// POST /clear-completed — delete all completed tasks
app.post('/clear-completed', (req, res) => {
  let tasks = getTasks().filter(t => !t.completed);
  saveTasks(tasks);
  res.redirect('/');
});

// Start server
app.listen(PORT, () => {
  console.log(`\n✅ TaskFlow running at http://localhost:${PORT}\n`);
});
