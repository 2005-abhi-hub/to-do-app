// ── Character counter for task input ──
const taskInput = document.getElementById('taskInput');
const charCount = document.getElementById('charCount');

if (taskInput && charCount) {
  const max = parseInt(taskInput.getAttribute('maxlength')) || 120;

  taskInput.addEventListener('input', () => {
    const remaining = max - taskInput.value.length;
    charCount.textContent = remaining;
    charCount.style.color = remaining < 20 ? '#f87171' : '';
  });

  // Auto-focus on load
  taskInput.focus();
}

// ── Set min date for due date picker to today ──
const dueDateInput = document.getElementById('dueDate');
if (dueDateInput) {
  const today = new Date().toISOString().split('T')[0];
  dueDateInput.setAttribute('min', today);
}

// ── Animate task items on load ──
const items = document.querySelectorAll('.task-item');
items.forEach((item, i) => {
  item.style.animationDelay = `${i * 0.04}s`;
});

// ── Flash highlight after add ──
const urlParams = new URLSearchParams(window.location.search);
if (!urlParams.has('filter') && !urlParams.has('priority')) {
  const firstItem = document.querySelector('.task-list .task-item');
  if (firstItem) {
    firstItem.style.boxShadow = '0 0 0 2px rgba(16,185,129,0.4)';
    setTimeout(() => { firstItem.style.boxShadow = ''; }, 1500);
  }
}
